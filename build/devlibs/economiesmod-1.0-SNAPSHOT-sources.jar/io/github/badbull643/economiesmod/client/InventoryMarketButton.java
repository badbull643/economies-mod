package io.github.badbull643.economiesmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.badbull643.economiesmod.mixin.HandledScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

/**
 * A way into the market from the inventory, next to the recipe book.
 *
 * The keybind is not discoverable. Nothing in the game says the market is on M, so a
 * player who installs the mod and never reads its page never finds it — and the
 * inventory is both where items live and where someone wondering what to do with their
 * items already is.
 *
 * Added, never substituted: M still works and is still the fast way in. This is the
 * path for people who don't know M exists yet.
 */
public final class InventoryMarketButton {

    /**
     * Beside vanilla's recipe-book button, which sits at x+104 and is 20 wide.
     *
     * The band between the crafting grid and the inventory rows is empty in the vanilla
     * texture, and the recipe book expands leftward, so nothing here gets covered when
     * it opens.
     */
    private static final int OFFSET_X = 126;
    private static final int WIDTH = 20;
    private static final int HEIGHT = 18;

    private static final Text LABEL = new LiteralText("Market");

    private InventoryMarketButton() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledW, scaledH) -> {
            if (!(screen instanceof InventoryScreen)) return;
            Screens.getButtons(screen).add(new OpenMarket((InventoryScreen) screen));
        });
    }

    /**
     * Extends PressableWidget rather than ButtonWidget purely for draw order.
     *
     * ButtonWidget.renderButton draws the background and then, if hovered, the tooltip —
     * which leaves nowhere to put the icon: after that call it lands on top of the
     * tooltip, before it the background covers it. PressableWidget draws only the
     * background, so the three can be sequenced properly.
     */
    private static final class OpenMarket extends PressableWidget {

        private final InventoryScreen owner;

        OpenMarket(InventoryScreen owner) {
            super(0, 0, WIDTH, HEIGHT, LABEL);
            this.owner = owner;
        }

        @Override
        public void onPress() {
            MinecraftClient.getInstance().openScreen(new MarketScreen());
        }

        @Override
        public void renderButton(MatrixStack m, int mouseX, int mouseY, float delta) {
            follow();
            super.renderButton(m, mouseX, mouseY, delta);
            drawEmerald(m);
            if (isHovered()) owner.renderTooltip(m, LABEL, mouseX, mouseY);
        }

        /**
         * Re-anchors to the panel every frame.
         *
         * init() is not enough: opening the recipe book shifts the whole GUI and only
         * vanilla's own button is moved to match. Doing it here rather than from a
         * render callback also means it survives init() running more than once, which
         * it does on every window resize.
         */
        private void follow() {
            this.x = ((HandledScreenAccessor) owner).getPanelX() + OFFSET_X;
            this.y = owner.height / 2 - 22;
        }

        /** The emerald is the mod's mark for money, and matches the credit line. */
        private void drawEmerald(MatrixStack m) {
            ItemRenderer items = MinecraftClient.getInstance().getItemRenderer();

            // HandledScreen turns depth testing off before rendering its buttons, and
            // item models need it on. Turn it back off afterwards rather than leaving it
            // — a stray enabled depth test is what made panels punch through each other
            // the last time icons were drawn outside a place that expected them.
            items.zOffset = 100.0F;
            RenderSystem.enableDepthTest();
            items.renderInGui(new ItemStack(Items.EMERALD), this.x + 2, this.y + 1);
            items.zOffset = 0.0F;
            RenderSystem.disableDepthTest();
        }
    }
}
