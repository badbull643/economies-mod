package io.github.badbull643.economiesmod.core;

import java.util.HashMap;
import java.util.Map;


public class ItemBalanceRegistry {

    private final Map<Long, Map<Integer,Long>> balances = new HashMap<>();
    public long getBalance(long userId, int itemId) {
        Map<Integer, Long> UserBalances = balances.get(userId);
        if (UserBalances == null) return 0L;
        return UserBalances.getOrDefault(itemId, 0L);
    }

    public void adjust(long userId, int itemId, long delta) {
        Map<Integer, Long> userBalances = balances.computeIfAbsent(userId, k -> new HashMap<>());
        userBalances.merge(itemId, delta, Long::sum);
    }

    Map<Long, Map<Integer, Long>> balances() { return balances; }

}
