package io.github.badbull643.economiesmod.client;

import io.github.badbull643.economiesmod.core.MarketState;
import java.io.IOException;
import java.nio.file.Path;

public class MarketStateHolder {
    private static MarketState current;
    private static Path currentFile;

    public static MarketState get() {
        if (current == null) current = new MarketState();
        return current;
    }

    public static void load(Path worldDir) {
        currentFile = worldDir.resolve("economiesmod").resolve("market.json");
        try {
            current = MarketState.loadFrom(currentFile);
            System.out.println("[economiesmod] loaded market from " + currentFile);
        } catch (IOException e) {
            System.err.println("[economiesmod] load failed, starting fresh: " + e);
            current = new MarketState();
        }
    }

    public static void save() {
        if (current == null || currentFile == null) return;
        try {
            current.saveTo(currentFile);
            System.out.println("[economiesmod] saved market to " + currentFile);
        } catch (IOException e) {
            System.err.println("[economiesmod] save failed: " + e);
        }
    }
}
