package io.github.badbull643.economiesmod.client;

import io.github.badbull643.economiesmod.core.Fill;
import io.github.badbull643.economiesmod.core.Settings;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_5250;

/**
 * Tells you when one of your orders trades.
 *
 * The point of a market you can log off from is that things happen while you are not
 * looking. Without this the only way to find out was to open the screen and compare
 * numbers against what you remembered — which is not something anyone does.
 *
 * Rate limited, because a market-maker on a busy host can have dozens of orders fill
 * in a second and a message per fill would bury the chat. Over the limit, fills are
 * batched into one line: you lose the detail, never the news.
 */
public final class FillNotifier {

    private static final long WINDOW_MS = 60_000L;

    private long windowStarted = System.currentTimeMillis();
    private int sentThisWindow;

    private int batchedFills;
    private long batchedNet;

    /**
     * Records a fill the local player was part of.
     *
     * @param resting true when the player's order was the one sitting on the book —
     *                the case worth being told about, since the other kind happened
     *                because they just pressed a button.
     */
    public void onFill(Fill fill, UUID me, boolean resting) {
        Settings settings = MarketStateHolder.settings();
        if (settings == null) return;
        if (!settings.notifyChat() && !settings.notifyActionBar()) return;

        boolean bought = me.equals(fill.buyerId());
        boolean sold = me.equals(fill.sellerId());
        if (!bought && !sold) return;
        // Trading with yourself nets to nothing and is not news.
        if (bought && sold) return;

        long delta = bought ? -fill.amount() : fill.amount();

        rollWindow();
        int limit = settings.notifyMaxPerMinute();
        if (limit > 0 && sentThisWindow < limit) {
            sentThisWindow++;
            send(settings, line(fill, bought, delta, resting), shortLine(fill, bought, delta));
        } else {
            batchedFills++;
            batchedNet += delta;
        }
    }

    /** Flushes any batched fills once their window closes. Call from the client tick. */
    public void tick() {
        if (batchedFills == 0) return;
        if (System.currentTimeMillis() - windowStarted < WINDOW_MS) return;

        Settings settings = MarketStateHolder.settings();
        if (settings != null) {
            class_5250 text = prefix()
                    .method_10852(new class_2585(batchedFills + " more fills")
                            .method_27692(class_124.field_1068))
                    .method_10852(new class_2585(" · ").method_27692(class_124.field_1063))
                    .method_10852(credits(batchedNet));
            send(settings, text, new class_2585(batchedFills + " fills " )
                    .method_27692(class_124.field_1080).method_10852(credits(batchedNet)));
        }

        batchedFills = 0;
        batchedNet = 0;
        rollWindow();
    }

    private void rollWindow() {
        long now = System.currentTimeMillis();
        if (now - windowStarted >= WINDOW_MS) {
            windowStarted = now;
            sentThisWindow = 0;
        }
    }

    /** The server-notice look: a coloured tag, then the message. */
    private static class_5250 prefix() {
        return new class_2585("[").method_27692(class_124.field_1063)
                .method_10852(new class_2585("Exchange").method_27692(class_124.field_1065))
                .method_10852(new class_2585("] ").method_27692(class_124.field_1063));
    }

    private static class_5250 credits(long delta) {
        String sign = delta >= 0 ? "+" : "";
        return new class_2585(sign + delta + "cr")
                .method_27692(delta >= 0 ? class_124.field_1060 : class_124.field_1061);
    }

    private static String itemName(Fill fill) {
        class_1792 item = MinecraftIds.idToItem(fill.itemId());
        return item == class_1802.field_8162 ? fill.itemId() : item.method_7848().getString();
    }

    private class_5250 line(Fill fill, boolean bought, long delta, boolean resting) {
        class_5250 text = prefix();
        // Only the resting case is really a notification; the other is feedback for
        // something the player did a moment ago, and saying so keeps them apart.
        text.method_10852(new class_2585(resting
                        ? (bought ? "Your buy order filled: " : "Your sell order filled: ")
                        : (bought ? "Bought " : "Sold "))
                .method_27692(resting ? class_124.field_1075 : class_124.field_1080));

        text.method_10852(new class_2585(fill.quantity() + " " + itemName(fill))
                .method_27692(class_124.field_1068));
        text.method_10852(new class_2585(" @ ").method_27692(class_124.field_1063));
        text.method_10852(new class_2585(String.valueOf(fill.price()))
                .method_27692(class_124.field_1054));
        text.method_10852(new class_2585(" · ").method_27692(class_124.field_1063));
        text.method_10852(credits(delta));
        return text;
    }

    /** The action bar overwrites itself, so it gets the short version. */
    private class_5250 shortLine(Fill fill, boolean bought, long delta) {
        return new class_2585((bought ? "Bought " : "Sold ") + fill.quantity() + " ")
                .method_27692(class_124.field_1080)
                .method_10852(new class_2585(itemName(fill)).method_27692(class_124.field_1068))
                .method_10852(new class_2585(" ").method_27692(class_124.field_1063))
                .method_10852(credits(delta));
    }

    private void send(Settings settings, class_5250 chat, class_5250 actionBar) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        // Never Screen.sendMessage — that broadcasts to the server as player chat.
        // These are notices to one person about their own orders.
        if (settings.notifyChat()) {
            mc.field_1724.method_7353(chat, false);
        }
        if (settings.notifyActionBar()) {
            mc.field_1724.method_7353(actionBar, true);
        }
    }
}
