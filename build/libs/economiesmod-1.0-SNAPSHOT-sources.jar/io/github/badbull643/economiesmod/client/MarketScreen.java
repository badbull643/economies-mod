package io.github.badbull643.economiesmod.client;

import io.github.badbull643.economiesmod.core.*;
import io.github.badbull643.economiesmod.core.net.PeerPoll;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5218;

public class MarketScreen extends class_437 {

    private class_342 amountField;
    private class_342 itemField;
    private class_342 priceField;
    private class_342 hostField;
    private class_342 cancelField;
    private class_342 hostPortField;
    private class_342 marketNameField;
    private class_4185 hostButton;
    private class_4185 createButton;
    private class_4185 importButton;
    private class_4185 migrateButton;
    private boolean migrateArmed = false;

    /** Set from the game thread by button handlers, and from the network thread
     *  by callbacks — hence volatile. */
    private static volatile String status = "";

    private static final int FIELD_HEIGHT = 20;
    private static final int AMOUNT_W = 50;
    private static final int ITEM_W = 160;
    private static final int PRICE_W = 50;
    private static final int ITEM_X_OFF = AMOUNT_W + 10;              // 60
    private static final int PRICE_X_OFF = ITEM_X_OFF + ITEM_W + 10;  // 230
    private static final int ROW_WIDTH = PRICE_X_OFF + PRICE_W;       // 280
    private static final long MAX_QTY = 100_000L;

    private boolean resetArmed = false;
    private boolean hostArmed = false;
    // Row positions, set in init() so render and hit-tests can't drift.
    private int rowX;
    private int rowY;
    private int buttonsY;
    private int cancelY;
    private int connY;

    private static String savedHostText = "localhost:25555";
    private static String savedPortText = "25555";
    private static String savedItemText = "minecraft:iron_ingot";
    private static String savedMarketName = "";

    private boolean createArmed = false;
    private boolean importArmed = false;

    public MarketScreen() {
        super(new class_2585("Market"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        MarketStateHolder.setOnRejected(reason -> status = "Rejected: " + reason);

        this.rowX = (int) (this.field_22789 * 0.42);
        this.rowY = (int) (this.field_22790 * 0.28);
        this.buttonsY = rowY + FIELD_HEIGHT + 40;
        this.cancelY = buttonsY + 64;
        this.connY = cancelY + 32;

        // ─── Trade entry fields ───
        this.amountField = new class_342(this.field_22793,
                rowX, rowY, AMOUNT_W, FIELD_HEIGHT, new class_2585("Amount"));
        this.itemField = new class_342(this.field_22793,
                rowX + ITEM_X_OFF, rowY, ITEM_W, FIELD_HEIGHT, new class_2585("Item"));
        this.priceField = new class_342(this.field_22793,
                rowX + PRICE_X_OFF, rowY, PRICE_W, FIELD_HEIGHT, new class_2585("Price"));

        this.itemField.method_1880(64);
        this.itemField.method_1852(savedItemText);

        this.method_25429(this.amountField);
        this.method_25429(this.itemField);
        this.method_25429(this.priceField);

        int buttonWidth = 74;

        // ─── Row 1: Buy / Sell ───
        this.method_25411(new class_4185(rowX, buttonsY, buttonWidth, FIELD_HEIGHT,
                new class_2585("Buy"), b -> onBuy()));
        this.method_25411(new class_4185(rowX + ROW_WIDTH - buttonWidth, buttonsY,
                buttonWidth, FIELD_HEIGHT, new class_2585("Sell"), b -> onSell()));

        // ─── Row 2: Withdraw / credits ───
        this.method_25411(new class_4185(rowX, buttonsY + 24, 100, FIELD_HEIGHT,
                new class_2585("Withdraw"), b -> onWithdraw()));

        // Sharing a market by file is how someone joins who was never online at the
        // same time as anyone holding it.
        this.method_25411(new class_4185(rowX + 110, buttonsY + 24, 80, FIELD_HEIGHT,
                new class_2585("Export"), b -> onExport()));
        this.importButton = new class_4185(rowX + 200, buttonsY + 24, 80, FIELD_HEIGHT,
                new class_2585("Import"), b -> onImport());
        this.method_25411(this.importButton);

        // ─── Row 3: cancel by order id ───
        this.cancelField = new class_342(this.field_22793,
                rowX, cancelY, 60, FIELD_HEIGHT, new class_2585("Order ID"));
        this.method_25429(this.cancelField);
        this.method_25411(new class_4185(rowX + 70, cancelY, 70, FIELD_HEIGHT,
                new class_2585("Cancel"), b -> onCancel()));

        // ─── Row 4: connection ───
        this.hostField = new class_342(this.field_22793,
                rowX, connY, 140, FIELD_HEIGHT, new class_2585("Host"));
        this.hostField.method_1880(64);
        this.hostField.method_1852(savedHostText);
        this.method_25429(this.hostField);

        this.method_25411(new class_4185(rowX + 150, connY, 70, FIELD_HEIGHT,
                new class_2585("Connect"), b -> onConnect()));

        // Host serves the market this world already holds. With no market there is
        // nothing to serve, so the button is disabled rather than silently creating
        // one — that silent creation is what fragments a friend group into two
        // permanently incompatible economies.
        this.hostButton = new class_4185(rowX + 230, connY, 70, FIELD_HEIGHT,
                new class_2585("Host"), b -> onHost());
        this.hostButton.field_22763 = MarketStateHolder.hasMarket();
        this.method_25411(this.hostButton);

        this.hostPortField = new class_342(this.field_22793,
                rowX + 310, connY, 45, FIELD_HEIGHT, new class_2585("Port"));
        this.hostPortField.method_1852(savedPortText);
        this.method_25429(this.hostPortField);

        // ─── Row 5: disconnect / stop ───
        this.migrateButton = new class_4185(rowX, connY + 24, 140, FIELD_HEIGHT,
                new class_2585("Migrate to host"), b -> onMigrate());
        this.method_25411(this.migrateButton);

        this.method_25411(new class_4185(rowX + 150, connY + 24, 70, FIELD_HEIGHT,
                new class_2585("Disconnect"), b -> onDisconnect()));
        this.method_25411(new class_4185(rowX + 230, connY + 24, 70, FIELD_HEIGHT,
                new class_2585("Stop"), b -> onStopHosting()));

        // ─── Row 6: log reset, discovery refresh, and creating a market ───
        // All on one row: this screen already runs off the bottom at GUI scale 3+,
        // so a new row would push the discovery list off-screen.
        this.method_25411(new class_4185(rowX, connY + 48, 70, FIELD_HEIGHT,
                new class_2585("Reset log"), b -> onReset()));
        this.method_25411(new class_4185(rowX + 75, connY + 48, 60, FIELD_HEIGHT,
                new class_2585("Refresh"), b -> startPoll()));

        this.marketNameField = new class_342(this.field_22793,
                rowX + 140, connY + 48, 110, FIELD_HEIGHT, new class_2585("Market name"));
        this.marketNameField.method_1880(32);
        this.marketNameField.method_1852(savedMarketName);
        this.method_25429(this.marketNameField);

        this.createButton = new class_4185(rowX + 255, connY + 48, 100, FIELD_HEIGHT,
                new class_2585("Create market"), b -> onCreateMarket());
        this.createButton.field_22763 = !MarketStateHolder.hasMarket();
        this.method_25411(this.createButton);

        startPoll();
    }

    /** Trading requires a host — local writes would fork you from the shared market. */
    private boolean requireConnected() {
        // Tested on the live socket, not on mode: being in CONNECTED mode with a dead
        // client is exactly the case that used to let a trade through to fail later.
        if (MarketStateHolder.isConnected()) return true;

        status = MarketStateHolder.mode() == MarketStateHolder.Mode.CONNECTED
                ? "Connection to the host was lost — reconnect to trade"
                : "Market is closed — connect to a host or start hosting to trade";
        return false;
    }

    private void onReset() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        UUID me = MinecraftIds.userIdOf(mc.field_1724);

        if (!resetArmed) {
            resetArmed = true;
            status = "DISCARD everything? You would lose: "
                    + MarketStateHolder.describeLoss(me) + " — click again";
            return;
        }
        resetArmed = false;
        MarketStateHolder.resetLog();
        status = "Local history discarded";
    }

    // ─────────── connection ───────────

    private static long lastConnectAttempt = 0;

    private void onConnect() {
        long now = System.currentTimeMillis();
        if (now - lastConnectAttempt < 3000) {
            status = "Wait a moment before retrying";
            return;
        }
        lastConnectAttempt = now;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        String text = hostField.method_1882().trim();
        String host;
        int port = 25555;

        try {
            if (text.startsWith("[")) {
                // IPv6 in brackets: [2001:db8::1] or [2001:db8::1]:25555
                int close = text.indexOf(']');
                if (close < 0) {
                    status = "Bad address — missing closing bracket";
                    return;
                }
                host = text.substring(1, close);
                String rest = text.substring(close + 1);
                if (rest.startsWith(":")) {
                    port = Integer.parseInt(rest.substring(1));
                }
            } else if (text.indexOf(':') != text.lastIndexOf(':')) {
                // More than one colon and no brackets — a bare IPv6 address.
                host = text;
            } else {
                int colon = text.lastIndexOf(':');
                if (colon < 0) {
                    host = text;
                } else {
                    host = text.substring(0, colon);
                    port = Integer.parseInt(text.substring(colon + 1));
                }
            }
        } catch (NumberFormatException e) {
            status = "Bad port — use host:port or [ipv6]:port";
            return;
        }

        // in onConnect, before spawning the thread
        try {
            MarketStateHolder.setMyHostPort(Integer.parseInt(hostPortField.method_1882().trim()));
        } catch (NumberFormatException ignored) { }

        final String finalHost = host;
        final int finalPort = port;

        status = "Connecting to " + finalHost + ":" + finalPort + "...";
        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        String myName = mc.method_1548().method_1676();

        new Thread(() -> {
            MarketStateHolder.connect(finalHost, finalPort, me, myName);
            // Only report success here. Failures already went through onRejected with
            // the actual reason and what to do about it — overwriting that with a
            // generic "Connect failed" throws away the only useful part.
            if (MarketStateHolder.isConnected()) {
                status = "Connected to " + finalHost + ":" + finalPort;
            }
        }, "market-connect").start();
    }

    private void onDisconnect() {
        MarketStateHolder.disconnect();
        status = "Disconnected — using local market";
    }

    /**
     * Creates a new market. Two-click confirm, because the cost of doing this by
     * mistake is not recoverable: a market created here shares no history with any
     * market your friends are already using, and the two can never be merged.
     */
    private void onCreateMarket() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.method_1576() == null) return;

        String name = marketNameField.method_1882().trim();
        if (name.isEmpty()) {
            status = "Give the market a name first";
            return;
        }

        if (!createArmed) {
            createArmed = true;
            status = "This creates a SEPARATE market — anyone who joins it won't see "
                    + "trades from any market your friends already use. To join theirs "
                    + "instead, use Connect. Click again to create '" + name + "'";
            return;
        }
        createArmed = false;

        savedMarketName = name;
        Path worldDir = mc.method_1576().method_27050(class_5218.field_24188);
        UUID me = MinecraftIds.userIdOf(mc.field_1724);

        if (MarketStateHolder.createMarket(worldDir, me, name)) {
            status = "Created '" + name + "' — click Host to start serving it";
        }
    }

    /** Host and Create are mutually exclusive: you either hold a market or you don't. */
    private void refreshMarketButtons() {
        boolean has = MarketStateHolder.hasMarket();
        if (hostButton != null) hostButton.field_22763 = has;
        if (createButton != null) createButton.field_22763 = !has;
        // Import adopts a market, so it needs the same empty slate Create does.
        if (importButton != null) importButton.field_22763 = !has;
    }

    private void onExport() {
        new Thread(() -> {
            try {
                status = "Exported to " + MarketStateHolder.exportMarket();
            } catch (IOException e) {
                status = "Export failed: " + e.getMessage();
            }
        }, "market-export").start();
    }

    /**
     * Two-click, like Create — importing replaces what this world holds, and the
     * verification pass reads and checks every event, so it isn't instant.
     */
    private void onImport() {
        if (!importArmed) {
            importArmed = true;
            status = "Import adopts someone else's market as this world's — click again";
            return;
        }
        importArmed = false;

        status = "Verifying archive...";
        new Thread(() -> {
            try {
                status = "Imported " + MarketStateHolder.importMarket();
            } catch (MarketArchive.InvalidArchive e) {
                status = "Archive rejected: " + e.getMessage();
            } catch (IOException e) {
                status = "Import failed: " + e.getMessage();
            }
        }, "market-import").start();
    }

    private static long lastHostAttempt = 0;

    private void onHost() {


        // Warn only about a genuine collision — someone else already serving the same
        // Behind the market — Raft's election restriction, with the high-water mark
        // standing in for a quorum. Serving a log that is short of where the market has
        // reached refuses everyone who is current, and forks it outright the moment
        // this host trades. Checked before the collision warning because it holds
        // whether or not anyone else is hosting right now, which is the case that
        // actually bites: you come back after a week and nobody is around to tell you.
        long behind = MarketStateHolder.eventsBehind();
        if (!hostArmed && behind > 0) {
            hostArmed = true;
            status = "Your copy is " + behind + " events behind this market. Hosting now"
                    + " would refuse everyone who is up to date, and split the market if"
                    + " you trade — connect to someone first, or click Host again to"
                    + " serve it anyway";
            return;
        }

        // market. Another host on a different market is not our problem, and warning
        // about it trains people to click through the warning that matters.
        // Only if we actually know what's out there. A warning derived from a minute-old
        // poll is worse than none: it names a host that may have stopped since, and
        // teaches people to click through the confirm without reading it.
        if (!hostArmed && pollIsFresh()) {
            class_310 mcCheck = class_310.method_1551();
            String myUuid = mcCheck.field_1724 != null
                    ? MinecraftIds.userIdOf(mcCheck.field_1724).toString() : null;
            MarketState mine = MarketStateHolder.get();
            String myMarket = mine != null && mine.marketId() != null
                    ? mine.marketId().toString() : null;

            for (PeerPoll.HostInfo h : discovered) {
                boolean isOther = h.reply.userId != null && !h.reply.userId.equals(myUuid);
                boolean sameMarket = myMarket != null && myMarket.equals(h.reply.marketId);
                if (isOther && sameMarket) {
                    hostArmed = true;
                    status = h.reply.hostName + " is already hosting this market ("
                            + h.reply.lastSeq + " events). Two hosts at once will split "
                            + "it — connect to them instead, or click Host again to "
                            + "take over anyway";
                    return;
                }
            }
        }
        hostArmed = false;

        long now = System.currentTimeMillis();
        if (now - lastHostAttempt < 3000) {
            status = "Wait a moment before retrying";
            return;
        }
        lastHostAttempt = now;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.method_1576() == null) return;

        int hostPort;
        try {
            hostPort = Integer.parseInt(hostPortField.method_1882().trim());
        } catch (NumberFormatException e) {
            status = "Port must be a number";
            return;
        }
        if (hostPort < 1024 || hostPort > 65535) {
            status = "Port must be between 1024 and 65535";
            return;
        }

        Path worldDir = mc.method_1576().method_27050(class_5218.field_24188);
        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        String playerName = mc.method_1548().method_1676();

        status = "Starting host...";
        new Thread(() -> {
            MarketStateHolder.startHosting(worldDir, hostPort, me, playerName);
            status = MarketStateHolder.mode() == MarketStateHolder.Mode.HOSTING
                    ? "Hosting on port " + hostPort
                    : "Failed to start host";
        }, "market-host-start").start();
    }

    /**
     * Hands this world's market to the host in the address field, which credits what we
     * hold there. Two-click, because it ends with discarding this market.
     */
    private void onMigrate() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        MarketState mine = MarketStateHolder.get();
        if (mine == null || mine.marketId() == null) {
            status = "You hold no market to migrate — use Connect";
            return;
        }

        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        if (!migrateArmed) {
            migrateArmed = true;
            status = "Migrate '" + mine.marketName() + "' to that host? It will credit "
                    + MarketStateHolder.describeLoss(me) + " there, then this market is"
                    + " discarded — click again to confirm";
            return;
        }
        migrateArmed = false;

        String text = hostField.method_1882().trim();
        final String host;
        final int port;
        try {
            int colon = text.lastIndexOf(':');
            host = colon < 0 ? text : text.substring(0, colon);
            port = colon < 0 ? 25555 : Integer.parseInt(text.substring(colon + 1));
        } catch (NumberFormatException e) {
            status = "Bad port — use host:port";
            return;
        }

        Path worldDir = mc.method_1576() != null
                ? mc.method_1576().method_27050(class_5218.field_24188) : null;
        if (worldDir == null) return;
        String myName = mc.method_1548().method_1676();

        status = "Verifying your market with " + host + "...";
        new Thread(() -> {
            if (!MarketStateHolder.migrateTo(host, port, me)) return;   // reports its own reason

            // Only now is it safe to discard: the destination has recorded the claim.
            MarketStateHolder.resetLog();
            MarketStateHolder.connect(host, port, me, myName);
            status = MarketStateHolder.isConnected()
                    ? "Migrated — your balance is here. Old orders listed below to re-place."
                    : "Migrated, but could not connect — press Connect";
        }, "market-migrate").start();
    }

    private void onStopHosting() {
        MarketStateHolder.stopHosting();
        status = "Stopped hosting";
    }

    // ─────────── discovery ───────────

    private static volatile List<PeerPoll.HostInfo> discovered = Collections.emptyList();
    private static volatile boolean polling = false;
    private static final int DISCOVERY_ROW_HEIGHT = 12;

    /** When the last poll finished. A host list with no age on it is a list of claims
     *  about the past being read as claims about the present. */
    private static volatile long lastPollAt = 0;
    private static final long POLL_INTERVAL_MS = 10_000;
    /** Past this, the list is too old to base a decision on. */
    private static final long POLL_STALE_MS = 20_000;

    private static boolean pollIsFresh() {
        return lastPollAt != 0 && System.currentTimeMillis() - lastPollAt < POLL_STALE_MS;
    }

    private void startPoll() {
        if (polling) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        PeerCache cache = MarketStateHolder.peers();
        if (cache == null) {
            discovered = Collections.emptyList();
            return;
        }

        polling = true;
        String me = MinecraftIds.userIdOf(mc.field_1724).toString();

        new Thread(() -> {
            try {
                List<PeerCache.Peer> others = new ArrayList<>();
                for (PeerCache.Peer p : cache.all()) {
                    if (!me.equals(p.userId)) others.add(p);
                }
                discovered = PeerPoll.findHosts(others, cache, 2000);

                // Note how far the market has been seen to reach. This is the only
                // moment we learn it, and it has to outlive the poll — by the time
                // someone hosts while behind, the peer that knew better is usually
                // offline.
                for (PeerPoll.HostInfo h : discovered) {
                    if (h.reply.marketId == null) continue;
                    try {
                        MarketStateHolder.observeMarketHeight(
                                UUID.fromString(h.reply.marketId), h.reply.lastSeq);
                    } catch (IllegalArgumentException ignored) {
                        // malformed marketId from a peer — not ours to fix
                    }
                }
            } finally {
                lastPollAt = System.currentTimeMillis();
                polling = false;
            }
        }, "market-discovery").start();
    }

    private int discoveryStartY() {
        return connY + 76;
    }

    /**
     * Orders carried over from a migrated market, waiting to be re-placed.
     *
     * Shown with the destination's current price beside each one. The prices you set in
     * a dead economy mean nothing here, and the difference is usually invisible until
     * after you've clicked — so it goes on the row.
     */
    private void renderReplaceList(class_4587 matrices) {
        List<MarketStateHolder.OldOrder> old = MarketStateHolder.pendingReplace();
        if (old.isEmpty()) return;

        int x = rowX;
        int y = discoveryStartY();

        label(matrices, "Orders from your old market — click to re-place, "
                + "[X] to dismiss all:", x, y, 0xFFDD66);
        y += DISCOVERY_ROW_HEIGHT + 2;

        MarketState s = MarketStateHolder.get();
        for (MarketOldRow row : replaceRows()) {
            MarketStateHolder.OldOrder o = row.order;
            String here = "";
            if (s != null) {
                List<Order> book = o.isBid
                        ? s.bookFor(o.itemId).restingAsks()
                        : s.bookFor(o.itemId).restingBids();
                if (!book.isEmpty()) {
                    here = o.isBid
                            ? "   (best ask here: " + book.get(0).value() + ")"
                            : "   (best bid here: " + book.get(0).value() + ")";
                }
            }
            label(matrices, "  " + (o.isBid ? "Buy  " : "Sell ") + o.volume + " "
                    + shortItem(o.itemId) + " @ " + o.price + here, x, y, 0x88CCFF);
            y += DISCOVERY_ROW_HEIGHT;
        }
    }

    private static String shortItem(String itemId) {
        int colon = itemId.indexOf(':');
        return colon < 0 ? itemId : itemId.substring(colon + 1);
    }

    /** Wrapper so the render and hit-test iterate the same thing. */
    private static class MarketOldRow {
        final MarketStateHolder.OldOrder order;
        MarketOldRow(MarketStateHolder.OldOrder order) { this.order = order; }
    }

    /**
     * Re-places one carried-over order at its original price.
     *
     * A plain PlaceOrder — the items and credits are already in the ledger from the
     * migration, so there is nothing to deposit and no special path for this.
     */
    private void replaceOrder(MarketStateHolder.OldOrder o) {
        if (!requireConnected()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        Event.PlaceOrder p = new Event.PlaceOrder();
        p.userId = MinecraftIds.userIdOf(mc.field_1724);
        p.itemId = o.itemId;
        p.price = o.price;
        p.volume = o.volume;
        p.isBid = o.isBid;
        p.timestamp = System.currentTimeMillis();

        MarketStateHolder.pendingReplace().remove(o);
        report(MarketStateHolder.submit(p),
                "Re-placed " + o.volume + " " + shortItem(o.itemId) + " @ " + o.price,
                "Re-placing...");
    }

    private List<MarketOldRow> replaceRows() {
        List<MarketOldRow> rows = new ArrayList<>();
        for (MarketStateHolder.OldOrder o : MarketStateHolder.pendingReplace()) {
            rows.add(new MarketOldRow(o));
        }
        return rows;
    }

    private void renderDiscovery(class_4587 matrices) {
        // The re-place list takes this space while it exists — it's transient and
        // actionable, discovery is neither.
        if (!MarketStateHolder.pendingReplace().isEmpty()) {
            renderReplaceList(matrices);
            return;
        }

        int x = rowX;
        int y = discoveryStartY();

        // No running counter: it re-polls every 10s, so the age is almost always
        // uninteresting and a ticking number just pulls the eye. Say something only
        // when the list has actually gone stale, which now means polling is failing.
        boolean stale = !polling && lastPollAt != 0 && !pollIsFresh();
        label(matrices, stale ? "Hosts: (out of date)" : "Hosts:",
                x, y, stale ? 0xAA8844 : 0xFFFFFF);
        y += DISCOVERY_ROW_HEIGHT + 2;

        if (polling) {
            label(matrices, "  searching...", x, y, 0x808080);
            return;
        }

        List<PeerPoll.HostInfo> hosts = discovered;
        if (hosts.isEmpty()) {
            label(matrices, "  nobody hosting", x, y, 0x808080);
            return;
        }

        class_310 mc = class_310.method_1551();
        String myUuid = mc.field_1724 != null
                ? MinecraftIds.userIdOf(mc.field_1724).toString() : null;

        MarketState mine = MarketStateHolder.get();
        String myMarket = mine != null && mine.marketId() != null
                ? mine.marketId().toString() : null;

        for (PeerPoll.HostInfo h : hosts) {
            boolean isSelf = h.reply.userId != null && h.reply.userId.equals(myUuid);
            // Whether this host serves the market we hold decides whether clicking it
            // will work at all, so it belongs on the row rather than in a failure later.
            boolean joinable = myMarket == null || myMarket.equals(h.reply.marketId);
            String marketLabel = h.reply.marketName != null ? h.reply.marketName : "unnamed";

            String line = "  " + h.reply.hostName
                    + (isSelf ? " (you)" : "")
                    + "  [" + marketLabel + "]"
                    + (joinable ? "" : " (different market)")
                    + "  (" + h.reply.lastSeq + " events, "
                    + h.reply.clientCount + " online)";

            int colour = isSelf ? 0xAAAAAA : (joinable ? 0x88CCFF : 0x996666);
            label(matrices, line, x, y, colour);
            y += DISCOVERY_ROW_HEIGHT;
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // The re-place list occupies the discovery area while it exists, so it claims
        // clicks there first.
        if (button == 0 && !MarketStateHolder.pendingReplace().isEmpty()) {
            int x = rowX;
            int headerY = discoveryStartY();

            // Header doubles as dismiss — the list is a convenience, not an obligation.
            if (mouseX >= x && mouseX <= x + 300
                    && mouseY >= headerY && mouseY < headerY + DISCOVERY_ROW_HEIGHT) {
                MarketStateHolder.clearPendingReplace();
                status = "Dismissed — your balance is unaffected";
                return true;
            }

            int y = headerY + DISCOVERY_ROW_HEIGHT + 2;
            for (MarketOldRow row : replaceRows()) {
                if (mouseX >= x && mouseX <= x + 300
                        && mouseY >= y && mouseY < y + DISCOVERY_ROW_HEIGHT) {
                    replaceOrder(row.order);
                    return true;
                }
                y += DISCOVERY_ROW_HEIGHT;
            }
            return true;   // swallow stray clicks in this region
        }

        if (button == 0 && !polling) {
            class_310 mc = class_310.method_1551();
            String myUuid = mc.field_1724 != null
                    ? MinecraftIds.userIdOf(mc.field_1724).toString() : null;

            int x = rowX;
            int y = discoveryStartY() + DISCOVERY_ROW_HEIGHT + 2;

            for (PeerPoll.HostInfo h : discovered) {
                boolean isSelf = h.reply.userId != null && h.reply.userId.equals(myUuid);
                if (!isSelf && mouseX >= x && mouseX <= x + 220
                        && mouseY >= y && mouseY < y + DISCOVERY_ROW_HEIGHT) {
                    joinHost(h);
                    return true;
                }
                y += DISCOVERY_ROW_HEIGHT;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private void joinHost(PeerPoll.HostInfo h) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        try {
            MarketStateHolder.setMyHostPort(Integer.parseInt(hostPortField.method_1882().trim()));
        } catch (NumberFormatException ignored) { }

        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        String myName = mc.method_1548().method_1676();
        String addr = h.peer.address;
        int port = h.peer.port;
        String hostLabel = h.reply.hostName;

        status = "Connecting to " + hostLabel + "...";
        new Thread(() -> {
            MarketStateHolder.connect(addr, port, me, myName);
            if (MarketStateHolder.isConnected()) {
                status = "Connected to " + hostLabel;
            }
        }, "market-connect").start();
    }

    // ─────────── actions ───────────

    private OrderRequest parseForm() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) { status = "No player"; return null; }

        long qty, price;
        try {
            qty = Long.parseLong(amountField.method_1882().trim());
            price = Long.parseLong(priceField.method_1882().trim());
        } catch (NumberFormatException e) {
            status = "Amount and price must be whole numbers";
            return null;
        }
        if (qty <= 0 || price <= 0) { status = "Amount and price must be positive"; return null; }
        if (qty > MAX_QTY) { status = "Amount too large (max " + MAX_QTY + ")"; return null; }

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) { status = "Unknown item (try minecraft:iron_ingot)"; return null; }

        OrderRequest req = new OrderRequest();
        req.item = item;
        req.itemId = MinecraftIds.itemToId(item);
        req.userId = MinecraftIds.userIdOf(mc.field_1724);
        req.qty = qty;
        req.price = price;
        return req;
    }

    private void onSell() {
        if (!requireConnected()) return;
        OrderRequest req = parseForm();
        if (req == null) return;

        class_310 mc = class_310.method_1551();

        // Remove physical items FIRST — never credit before removing.
        if (!InventoryBridge.remove(mc.field_1724, req.item, (int) req.qty)) {
            status = "You don't have " + req.qty + " of that";
            return;
        }

        // Deposit and list as one atomic event — two separate proposals could be
        // interleaved, leaving items deposited but never listed.
        Event.DepositAndList e = new Event.DepositAndList();
        e.userId = req.userId;
        e.itemId = req.itemId;
        e.quantity = req.qty;
        e.price = req.price;
        e.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(e),
                "Listed " + req.qty + " at " + req.price, "Sell sent...");
    }

    private void onBuy() {
        if (!requireConnected()) return;
        OrderRequest req = parseForm();
        if (req == null) return;

        Event.PlaceOrder order = new Event.PlaceOrder();
        order.userId = req.userId;
        order.itemId = req.itemId;
        order.price = req.price;
        order.volume = req.qty;
        order.isBid = true;
        order.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(order),
                "Bid placed for " + req.qty + " at " + req.price, "Buy sent...");
    }

    private void onWithdraw() {
        if (!requireConnected()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) { status = "No player"; return; }

        long qty;
        try {
            qty = Long.parseLong(amountField.method_1882().trim());
        } catch (NumberFormatException e) {
            status = "Amount must be a whole number";
            return;
        }
        if (qty <= 0) { status = "Amount must be positive"; return; }
        if (qty > MAX_QTY) { status = "Amount too large"; return; }

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) { status = "Unknown item"; return; }

        Event.Withdraw w = new Event.Withdraw();
        w.userId = MinecraftIds.userIdOf(mc.field_1724);
        w.itemId = MinecraftIds.itemToId(item);
        w.quantity = qty;
        w.timestamp = System.currentTimeMillis();

        MarketStateHolder.Submission s = MarketStateHolder.submit(w);
        if (s.pending) {
            status = "Withdraw sent...";
        } else if (s.accepted) {
            status = "Withdrew " + qty;
        } else {
            status = "Rejected: " + s.reason;
        }
    }

    private void onCancel() {
        if (!requireConnected()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        long orderId;
        try {
            orderId = Long.parseLong(cancelField.method_1882().trim().replace("#", ""));
        } catch (NumberFormatException e) {
            status = "Order ID must be a number";
            return;
        }

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) { status = "Unknown item"; return; }

        // The event needs the side; find the order to work out which book it's in.
        String itemId = MinecraftIds.itemToId(item);
        OrderBook book = MarketStateHolder.get().bookFor(itemId);
        Order o = book.find(orderId, true);
        boolean isBid = o != null;
        if (o == null) o = book.find(orderId, false);
        if (o == null) { status = "No such order in this item's book"; return; }

        Event.CancelOrder c = new Event.CancelOrder();
        c.userId = MinecraftIds.userIdOf(mc.field_1724);
        c.itemId = itemId;
        c.orderId = orderId;
        c.isBid = isBid;
        c.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(c), "Cancelled #" + orderId, "Cancel sent...");
    }

    private void report(MarketStateHolder.Submission s, String successMsg, String pendingMsg) {
        if (s.pending) {
            status = pendingMsg;
        } else if (s.accepted) {
            status = s.result.fills.isEmpty()
                    ? successMsg
                    : "Traded — " + s.result.fills.size() + " fill(s)";
        } else {
            status = "Rejected: " + s.reason;
        }
    }

    // ─────────── rendering ───────────

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        method_25420(matrices);

        // Whether you hold a market changes from the network thread — connecting adopts
        // one, disconnecting or resetting can drop it. Recompute here rather than only
        // in init(), or the buttons stay wrong until the screen is reopened.
        // A dropped host is noticed on a network thread; fold it into the mode here so
        // the rest of the UI isn't reading state from a connection that's gone.
        MarketStateHolder.pollConnection();
        refreshMarketButtons();

        // Re-poll on a timer. Without this the host list only ever reflects the moment
        // the screen was opened, so a host that has since stopped still looks live.
        if (!polling && System.currentTimeMillis() - lastPollAt > POLL_INTERVAL_MS) {
            startPoll();
        }

        method_27534(matrices, this.field_22793, this.field_22785, this.field_22789 / 2, 16, 0xFFFFFF);

        int listX = (int) (this.field_22789 * 0.08);

        label(matrices, "Amount", rowX, rowY - 11, 0xA0A0A0);
        label(matrices, "Item", rowX + ITEM_X_OFF, rowY - 11, 0xA0A0A0);
        label(matrices, "Price", rowX + PRICE_X_OFF, rowY - 11, 0xA0A0A0);
        label(matrices, "Cancel order", rowX, cancelY - 11, 0xA0A0A0);
        label(matrices, "Order book:", listX, rowY - 11, 0xFFFFFF);
        label(matrices, "Port", rowX + 310, connY - 11, 0xA0A0A0);
        label(matrices, "New market name", rowX + 140, connY + 37, 0xA0A0A0);

        renderConnectionStatus(matrices, listX, 30);

        // Persistent, not a status-line message — this one doesn't get to scroll away.
        if (MarketStateHolder.chainBrokenAt() != -1) {
            String why = MarketStateHolder.damageReason();
            label(matrices, "LOG UNUSABLE — " + (why == null ? "damaged" : why),
                    listX, 42, 0xFF6666);
            label(matrices, "Reset log to continue", listX, 54, 0xFF6666);
        } else {
            long behind = MarketStateHolder.eventsBehind();
            if (behind > 0) {
                label(matrices, behind + " events behind — connect to catch up before hosting",
                        listX, 42, 0xFFAA55);
            }
        }
        renderBook(matrices, listX, rowY + 6);
        renderBalances(matrices, listX);
        renderDiscovery(matrices);

        if (!status.isEmpty()) {
            label(matrices, status, listX, this.field_22790 - 24, 0xFFDD66);
        }

        // Your identity is a file, and it doesn't follow you to a new computer. Moving
        // machines without it makes you a stranger to every market you were part of —
        // same username, same UUID, unrecognised key. Cheaper to say so than to debug.
        Path identity = MarketStateHolder.identityPath();
        if (identity != null) {
            label(matrices, "identity: config/" + identity.getFileName()
                            + "  — copy this to move computers, never share it",
                    listX, this.field_22790 - 12, 0x707070);
        }

        this.amountField.method_25394(matrices, mouseX, mouseY, delta);
        this.itemField.method_25394(matrices, mouseX, mouseY, delta);
        this.priceField.method_25394(matrices, mouseX, mouseY, delta);
        this.hostField.method_25394(matrices, mouseX, mouseY, delta);
        this.cancelField.method_25394(matrices, mouseX, mouseY, delta);
        this.hostPortField.method_25394(matrices, mouseX, mouseY, delta);
        this.marketNameField.method_25394(matrices, mouseX, mouseY, delta);

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    private void renderConnectionStatus(class_4587 matrices, int x, int y) {
        if (MarketStateHolder.mode() == MarketStateHolder.Mode.HOSTING) {
            label(matrices, "● hosting", x, y, 0xFFDD66);
        } else if (MarketStateHolder.isConnected()) {
            label(matrices, "● connected to host", x, y, 0x88FF88);
        } else if (MarketStateHolder.mode() == MarketStateHolder.Mode.CONNECTED) {
            label(matrices, "● connection lost", x, y, 0xFF8888);
        } else {
            label(matrices, "● market closed — not connected", x, y, 0xAAAAAA);
        }
    }

    private void renderBook(class_4587 matrices, int x, int startY) {
        class_310 mc = class_310.method_1551();
        UUID myUuid = mc.field_1724 != null ? MinecraftIds.userIdOf(mc.field_1724) : null;

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) {
            label(matrices, "(enter an item to see its book)", x, startY, 0x808080);
            return;
        }

        String itemId = MinecraftIds.itemToId(item);
        MarketState market = MarketStateHolder.get();
        List<Order> asks = market.bookFor(itemId).restingAsks();
        List<Order> bids = market.bookFor(itemId).restingBids();

        if (asks.isEmpty() && bids.isEmpty()) {
            label(matrices, "(no orders)", x, startY, 0x808080);
            return;
        }

        int y = startY;
        int rowHeight = 13;

        int shown = 0;
        for (Order o : asks) {
            if (shown++ >= 6) break;
            boolean mine = myUuid != null && o.userID().equals(myUuid);
            label(matrices, (mine ? "* " : "  ") + "#" + o.orderId()
                            + " SELL " + o.volume() + " @ " + o.value(),
                    x, y, mine ? 0xFFCC66 : 0xFF8888);
            y += rowHeight;
        }

        y += 4;
        shown = 0;
        for (Order o : bids) {
            if (shown++ >= 6) break;
            boolean mine = myUuid != null && o.userID().equals(myUuid);
            label(matrices, (mine ? "* " : "  ") + "#" + o.orderId()
                            + " BUY  " + o.volume() + " @ " + o.value(),
                    x, y, mine ? 0xFFCC66 : 0x88FF88);
            y += rowHeight;
        }
    }

    private void renderBalances(class_4587 matrices, int x) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        UUID userId = MinecraftIds.userIdOf(mc.field_1724);
        MarketState market = MarketStateHolder.get();

        int y = this.field_22790 - 50;
        label(matrices, "Credits: " + market.wallets().getBalance(userId), x, y, 0xFFFF88);

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item != class_1802.field_8162) {
            long held = market.itemBalances().getBalance(userId, MinecraftIds.itemToId(item));
            label(matrices, "Market credit: " + held + " " + item.method_7848().getString(),
                    x, y + 13, 0xFFFF88);
        }
    }

    private void label(class_4587 m, String s, int x, int y, int colour) {
        method_27535(m, this.field_22793, new class_2585(s), x, y, colour);
    }

    private static class OrderRequest {
        class_1792 item;
        String itemId;
        UUID userId;
        long qty;
        long price;
    }

    /** Reads the port field, falling back to 25555 if it's not a valid number. */
    private int hostPortFromField() {
        try {
            int p = Integer.parseInt(hostPortField.method_1882().trim());
            return (p >= 1024 && p <= 65535) ? p : 25555;
        } catch (NumberFormatException e) {
            return 25555;
        }
    }

    @Override
    public void method_25432() {
        resetArmed = false;
        hostArmed = false;
        savedItemText = itemField.method_1882();
        savedItemText = itemField.method_1882();
        savedHostText = hostField.method_1882();
        savedPortText = hostPortField.method_1882();
        super.method_25432();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_M
                && !amountField.method_25370()
                && !itemField.method_25370()
                && !priceField.method_25370()
                && !hostField.method_25370()
                && !hostPortField.method_25370()
                && !cancelField.method_25370()) {
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

}