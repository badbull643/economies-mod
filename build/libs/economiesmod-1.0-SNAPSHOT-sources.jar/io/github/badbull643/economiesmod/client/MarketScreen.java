package io.github.badbull643.economiesmod.client;

import java.util.List;
import net.minecraft.class_2585;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class MarketScreen extends class_437 {

    private class_342 amountField;
    private class_342 itemField;
    private class_342 priceField;

    // ---- Layout anchors (computed in init, used everywhere) ----
    private int panelX;        // left edge of the right-hand panel
    private int rowAmountY;     // Y of the amount field
    private int rowItemY;       // Y of the item field
    private int rowPriceY;      // Y of the price field
    private int buttonsY;       // Y of the buy/sell buttons

    private static final int FIELD_WIDTH = 80;    // narrower, since 3 sit side by side
    private static final int FIELD_HEIGHT = 20;
    private static final int FIELD_GAP = 16;
    private static final int ROW_GAP = 34;     // vertical distance between rows
    private static final int LABEL_OFFSET = 11;


    private final java.util.List<FakeOrder> fakeOrders = java.util.Arrays.asList(
            new FakeOrder(500, 247),
            new FakeOrder(320, 246),
            new FakeOrder(150, 244)
    );

    public MarketScreen() {
        super(new class_2585("Market"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        // Starting X for the row of fields, and a shared Y
        int rowX = (int) (this.field_22789 * 0.42);
        int rowY = (int) (this.field_22790 * 0.28);

        this.amountField = new class_342(this.field_22793,
                rowX, rowY, FIELD_WIDTH, FIELD_HEIGHT, new class_2585("Amount"));
        this.itemField = new class_342(this.field_22793,
                rowX + (FIELD_WIDTH + FIELD_GAP), rowY, FIELD_WIDTH, FIELD_HEIGHT, new class_2585("Item"));
        this.priceField = new class_342(this.field_22793,
                rowX + (FIELD_WIDTH + FIELD_GAP) * 2, rowY, FIELD_WIDTH, FIELD_HEIGHT, new class_2585("Price"));

        this.method_25429(this.amountField);
        this.method_25429(this.itemField);
        this.method_25429(this.priceField);

        // Buy / Sell buttons below the row of fields
        int buttonsY = rowY + FIELD_HEIGHT + 40;
        int buttonWidth = 74;

        // Buy under the first field, Sell under the third — bracketing the row like your sketch
        this.method_25411(new class_4185(
                rowX, buttonsY, buttonWidth, FIELD_HEIGHT,
                new class_2585("Buy"),
                button -> onBuy()));

        this.method_25411(new class_4185(
                rowX + (FIELD_WIDTH + FIELD_GAP) * 2 + FIELD_WIDTH - buttonWidth, buttonsY, buttonWidth, FIELD_HEIGHT,
                new class_2585("Sell"),
                button -> onSell()));
    }

    private void onBuy() {
        System.out.println("BUY  amount=" + amountField.method_1882()
                + " item=" + itemField.method_1882()
                + " price=" + priceField.method_1882());
    }

    private void onSell() {
        System.out.println("SELL amount=" + amountField.method_1882()
                + " item=" + itemField.method_1882()
                + " price=" + priceField.method_1882());
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        method_25420(matrices);

        method_27534(matrices, this.field_22793, this.field_22785,
                this.field_22789 / 2, 16, 0xFFFFFF);

        int rowX = (int) (this.field_22789 * 0.42);
        int rowY = (int) (this.field_22790 * 0.28);

        // Labels above each field
        method_27535(matrices, this.field_22793, new class_2585("Amount"),
                rowX, rowY - 11, 0xA0A0A0);
        method_27535(matrices, this.field_22793, new class_2585("Item"),
                rowX + (FIELD_WIDTH + FIELD_GAP), rowY - 11, 0xA0A0A0);
        method_27535(matrices, this.field_22793, new class_2585("Price"),
                rowX + (FIELD_WIDTH + FIELD_GAP) * 2, rowY - 11, 0xA0A0A0);

        // Order book heading (left)
        method_27535(matrices, this.field_22793, new class_2585("Order book:"),
                (int) (this.field_22789 * 0.08), rowY - 11, 0xFFFFFF);

        // Draw the fields explicitly
        this.amountField.method_25394(matrices, mouseX, mouseY, delta);
        this.itemField.method_25394(matrices, mouseX, mouseY, delta);
        this.priceField.method_25394(matrices, mouseX, mouseY, delta);

        int listX = (int) (this.field_22789 * 0.08);
        int rowwY = (int) (this.field_22790 * 0.28);   // same rowY you use elsewhere
        int listStartY = rowwY + 6;               // first order sits just below the heading
        int rowHeight = 13;

        for (int i = 0; i < fakeOrders.size(); i++) {
            FakeOrder order = fakeOrders.get(i);
            String line = "Order " + (i + 1) + "   x" + order.amount + "   @" + order.price;
            method_27535(matrices, this.field_22793, new class_2585(line),
                    listX, listStartY + i * rowHeight, 0xE0E0E0);
        }

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;   // don't pause the game while the market is open
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // Close on M (GLFW key code 77), so M toggles the screen shut
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_M) {
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private static class FakeOrder {
        final int amount;
        final int price;
        FakeOrder(int amount, int price) { this.amount = amount; this.price = price; }
    }
}