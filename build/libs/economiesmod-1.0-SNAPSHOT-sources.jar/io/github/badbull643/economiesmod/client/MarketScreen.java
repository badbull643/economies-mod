package io.github.badbull643.economiesmod.client;

import io.github.badbull643.economiesmod.core.*;
import io.github.badbull643.economiesmod.core.net.PeerPoll;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5218;

public class MarketScreen extends class_437 {

    private class_342 amountField;
    private class_342 itemField;
    private class_342 priceField;
    private class_342 hostField;
    private class_342 cancelField;
    private class_342 hostPortField;

    /** Set from the game thread by button handlers, and from the network thread
     *  by callbacks — hence volatile. */
    private static volatile String status = "";

    private static final int FIELD_HEIGHT = 20;
    private static final int AMOUNT_W = 50;
    private static final int ITEM_W = 160;
    private static final int PRICE_W = 50;
    private static final int ITEM_X_OFF = AMOUNT_W + 10;              // 60
    private static final int PRICE_X_OFF = ITEM_X_OFF + ITEM_W + 10;  // 230
    private static final int ROW_WIDTH = PRICE_X_OFF + PRICE_W;       // 280
    private static final long MAX_QTY = 100_000L;

    private boolean resetArmed = false;
    private boolean hostArmed = false;
    // Row positions, set in init() so render and hit-tests can't drift.
    private int rowX;
    private int rowY;
    private int buttonsY;
    private int cancelY;
    private int connY;

    private static String savedHostText = "localhost:25555";
    private static String savedPortText = "25555";
    private static String savedItemText = "minecraft:iron_ingot";

    public MarketScreen() {
        super(new class_2585("Market"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        MarketStateHolder.setOnRejected(reason -> status = "Rejected: " + reason);

        this.rowX = (int) (this.field_22789 * 0.42);
        this.rowY = (int) (this.field_22790 * 0.28);
        this.buttonsY = rowY + FIELD_HEIGHT + 40;
        this.cancelY = buttonsY + 64;
        this.connY = cancelY + 32;

        // ─── Trade entry fields ───
        this.amountField = new class_342(this.field_22793,
                rowX, rowY, AMOUNT_W, FIELD_HEIGHT, new class_2585("Amount"));
        this.itemField = new class_342(this.field_22793,
                rowX + ITEM_X_OFF, rowY, ITEM_W, FIELD_HEIGHT, new class_2585("Item"));
        this.priceField = new class_342(this.field_22793,
                rowX + PRICE_X_OFF, rowY, PRICE_W, FIELD_HEIGHT, new class_2585("Price"));

        this.itemField.method_1880(64);
        this.itemField.method_1852(savedItemText);

        this.method_25429(this.amountField);
        this.method_25429(this.itemField);
        this.method_25429(this.priceField);

        int buttonWidth = 74;

        // ─── Row 1: Buy / Sell ───
        this.method_25411(new class_4185(rowX, buttonsY, buttonWidth, FIELD_HEIGHT,
                new class_2585("Buy"), b -> onBuy()));
        this.method_25411(new class_4185(rowX + ROW_WIDTH - buttonWidth, buttonsY,
                buttonWidth, FIELD_HEIGHT, new class_2585("Sell"), b -> onSell()));

        // ─── Row 2: Withdraw / credits ───
        this.method_25411(new class_4185(rowX, buttonsY + 24, 100, FIELD_HEIGHT,
                new class_2585("Withdraw"), b -> onWithdraw()));
        this.method_25411(new class_4185(rowX + 110, buttonsY + 24, 100, FIELD_HEIGHT,
                new class_2585("+1000 credits"), b -> onAddCredits()));

        // ─── Row 3: cancel by order id ───
        this.cancelField = new class_342(this.field_22793,
                rowX, cancelY, 60, FIELD_HEIGHT, new class_2585("Order ID"));
        this.method_25429(this.cancelField);
        this.method_25411(new class_4185(rowX + 70, cancelY, 70, FIELD_HEIGHT,
                new class_2585("Cancel"), b -> onCancel()));

        // ─── Row 4: connection ───
        this.hostField = new class_342(this.field_22793,
                rowX, connY, 140, FIELD_HEIGHT, new class_2585("Host"));
        this.hostField.method_1880(64);
        this.hostField.method_1852(savedHostText);
        this.method_25429(this.hostField);

        this.method_25411(new class_4185(rowX + 150, connY, 70, FIELD_HEIGHT,
                new class_2585("Connect"), b -> onConnect()));
        this.method_25411(new class_4185(rowX + 230, connY, 70, FIELD_HEIGHT,
                new class_2585("Host"), b -> onHost()));

        this.hostPortField = new class_342(this.field_22793,
                rowX + 310, connY, 45, FIELD_HEIGHT, new class_2585("Port"));
        this.hostPortField.method_1852(savedPortText);
        this.method_25429(this.hostPortField);

        // ─── Row 5: disconnect / stop ───
        this.method_25411(new class_4185(rowX + 150, connY + 24, 70, FIELD_HEIGHT,
                new class_2585("Disconnect"), b -> onDisconnect()));
        this.method_25411(new class_4185(rowX + 230, connY + 24, 70, FIELD_HEIGHT,
                new class_2585("Stop"), b -> onStopHosting()));

        // ─── Row 6: log reset and discovery refresh ───
        this.method_25411(new class_4185(rowX, connY + 48, 90, FIELD_HEIGHT,
                new class_2585("Reset log"), b -> onReset()));
        this.method_25411(new class_4185(rowX + 100, connY + 48, 90, FIELD_HEIGHT,
                new class_2585("Refresh"), b -> startPoll()));

        startPoll();
    }

    /** Trading requires a host — local writes would fork you from the shared market. */
    private boolean requireConnected() {
        if (MarketStateHolder.mode() == MarketStateHolder.Mode.LOCAL) {
            status = "Market is closed — connect to a host or start hosting to trade";
            return false;
        }
        return true;
    }

    private void onReset() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        UUID me = MinecraftIds.userIdOf(mc.field_1724);

        if (!resetArmed) {
            resetArmed = true;
            status = "DISCARD everything? You would lose: "
                    + MarketStateHolder.describeLoss(me) + " — click again";
            return;
        }
        resetArmed = false;
        MarketStateHolder.resetLog();
        status = "Local history discarded";
    }

    // ─────────── connection ───────────

    private static long lastConnectAttempt = 0;

    private void onConnect() {
        long now = System.currentTimeMillis();
        if (now - lastConnectAttempt < 3000) {
            status = "Wait a moment before retrying";
            return;
        }
        lastConnectAttempt = now;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        String text = hostField.method_1882().trim();
        String host;
        int port = 25555;

        try {
            if (text.startsWith("[")) {
                // IPv6 in brackets: [2001:db8::1] or [2001:db8::1]:25555
                int close = text.indexOf(']');
                if (close < 0) {
                    status = "Bad address — missing closing bracket";
                    return;
                }
                host = text.substring(1, close);
                String rest = text.substring(close + 1);
                if (rest.startsWith(":")) {
                    port = Integer.parseInt(rest.substring(1));
                }
            } else if (text.indexOf(':') != text.lastIndexOf(':')) {
                // More than one colon and no brackets — a bare IPv6 address.
                host = text;
            } else {
                int colon = text.lastIndexOf(':');
                if (colon < 0) {
                    host = text;
                } else {
                    host = text.substring(0, colon);
                    port = Integer.parseInt(text.substring(colon + 1));
                }
            }
        } catch (NumberFormatException e) {
            status = "Bad port — use host:port or [ipv6]:port";
            return;
        }

        // in onConnect, before spawning the thread
        try {
            MarketStateHolder.setMyHostPort(Integer.parseInt(hostPortField.method_1882().trim()));
        } catch (NumberFormatException ignored) { }

        final String finalHost = host;
        final int finalPort = port;

        status = "Connecting to " + finalHost + ":" + finalPort + "...";
        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        String myName = mc.method_1548().method_1676();

        new Thread(() -> {
            MarketStateHolder.connect(finalHost, finalPort, me, myName);
            status = MarketStateHolder.isConnected()
                    ? "Connected to " + finalHost + ":" + finalPort
                    : "Connect failed";
        }, "market-connect").start();
    }

    private void onDisconnect() {
        MarketStateHolder.disconnect();
        status = "Disconnected — using local market";
    }

    private static long lastHostAttempt = 0;

    private void onHost() {


        // Warn if someone else already appears to be hosting.
        if (!hostArmed) {
            class_310 mcCheck = class_310.method_1551();
            String myUuid = mcCheck.field_1724 != null
                    ? MinecraftIds.userIdOf(mcCheck.field_1724).toString() : null;

            for (PeerPoll.HostInfo h : discovered) {
                if (h.reply.userId != null && !h.reply.userId.equals(myUuid)) {
                    hostArmed = true;
                    status = h.reply.hostName + " is already hosting ("
                            + h.reply.lastSeq + " events). Hosting yourself creates a "
                            + "SEPARATE market — click Host again to do it anyway";
                    return;
                }
            }
        }
        hostArmed = false;

        long now = System.currentTimeMillis();
        if (now - lastHostAttempt < 3000) {
            status = "Wait a moment before retrying";
            return;
        }
        lastHostAttempt = now;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.method_1576() == null) return;

        int hostPort;
        try {
            hostPort = Integer.parseInt(hostPortField.method_1882().trim());
        } catch (NumberFormatException e) {
            status = "Port must be a number";
            return;
        }
        if (hostPort < 1024 || hostPort > 65535) {
            status = "Port must be between 1024 and 65535";
            return;
        }

        Path worldDir = mc.method_1576().method_27050(class_5218.field_24188);
        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        String playerName = mc.method_1548().method_1676();

        status = "Starting host...";
        new Thread(() -> {
            MarketStateHolder.startHosting(worldDir, hostPort, me, playerName);
            status = MarketStateHolder.mode() == MarketStateHolder.Mode.HOSTING
                    ? "Hosting on port " + hostPort
                    : "Failed to start host";
        }, "market-host-start").start();
    }

    private void onStopHosting() {
        MarketStateHolder.stopHosting();
        status = "Stopped hosting";
    }

    // ─────────── discovery ───────────

    private static volatile List<PeerPoll.HostInfo> discovered = Collections.emptyList();
    private static volatile boolean polling = false;
    private static final int DISCOVERY_ROW_HEIGHT = 12;

    private void startPoll() {
        if (polling) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        PeerCache cache = MarketStateHolder.peers();
        if (cache == null) {
            discovered = Collections.emptyList();
            return;
        }

        polling = true;
        String me = MinecraftIds.userIdOf(mc.field_1724).toString();

        new Thread(() -> {
            try {
                List<PeerCache.Peer> others = new ArrayList<>();
                for (PeerCache.Peer p : cache.all()) {
                    if (!me.equals(p.userId)) others.add(p);
                }
                discovered = PeerPoll.findHosts(others, 2000);
            } finally {
                polling = false;
            }
        }, "market-discovery").start();
    }

    private int discoveryStartY() {
        return connY + 76;
    }

    private void renderDiscovery(class_4587 matrices) {
        int x = rowX;
        int y = discoveryStartY();

        label(matrices, "Hosts:", x, y, 0xFFFFFF);
        y += DISCOVERY_ROW_HEIGHT + 2;

        if (polling) {
            label(matrices, "  searching...", x, y, 0x808080);
            return;
        }

        List<PeerPoll.HostInfo> hosts = discovered;
        if (hosts.isEmpty()) {
            label(matrices, "  nobody hosting", x, y, 0x808080);
            return;
        }

        class_310 mc = class_310.method_1551();
        String myUuid = mc.field_1724 != null
                ? MinecraftIds.userIdOf(mc.field_1724).toString() : null;

        for (PeerPoll.HostInfo h : hosts) {
            boolean isSelf = h.reply.userId != null && h.reply.userId.equals(myUuid);
            String line = "  " + h.reply.hostName
                    + (isSelf ? " (you)" : "")
                    + "  (" + h.reply.lastSeq + " events, "
                    + h.reply.clientCount + " online)";
            label(matrices, line, x, y, isSelf ? 0xAAAAAA : 0x88CCFF);
            y += DISCOVERY_ROW_HEIGHT;
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && !polling) {
            class_310 mc = class_310.method_1551();
            String myUuid = mc.field_1724 != null
                    ? MinecraftIds.userIdOf(mc.field_1724).toString() : null;

            int x = rowX;
            int y = discoveryStartY() + DISCOVERY_ROW_HEIGHT + 2;

            for (PeerPoll.HostInfo h : discovered) {
                boolean isSelf = h.reply.userId != null && h.reply.userId.equals(myUuid);
                if (!isSelf && mouseX >= x && mouseX <= x + 220
                        && mouseY >= y && mouseY < y + DISCOVERY_ROW_HEIGHT) {
                    joinHost(h);
                    return true;
                }
                y += DISCOVERY_ROW_HEIGHT;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private void joinHost(PeerPoll.HostInfo h) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        try {
            MarketStateHolder.setMyHostPort(Integer.parseInt(hostPortField.method_1882().trim()));
        } catch (NumberFormatException ignored) { }

        UUID me = MinecraftIds.userIdOf(mc.field_1724);
        String myName = mc.method_1548().method_1676();
        String addr = h.peer.address;
        int port = h.peer.port;
        String hostLabel = h.reply.hostName;

        status = "Connecting to " + hostLabel + "...";
        new Thread(() -> {
            MarketStateHolder.connect(addr, port, me, myName);
            status = MarketStateHolder.isConnected()
                    ? "Connected to " + hostLabel
                    : "Connect failed";
        }, "market-connect").start();
    }

    // ─────────── actions ───────────

    private OrderRequest parseForm() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) { status = "No player"; return null; }

        long qty, price;
        try {
            qty = Long.parseLong(amountField.method_1882().trim());
            price = Long.parseLong(priceField.method_1882().trim());
        } catch (NumberFormatException e) {
            status = "Amount and price must be whole numbers";
            return null;
        }
        if (qty <= 0 || price <= 0) { status = "Amount and price must be positive"; return null; }
        if (qty > MAX_QTY) { status = "Amount too large (max " + MAX_QTY + ")"; return null; }

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) { status = "Unknown item (try minecraft:iron_ingot)"; return null; }

        OrderRequest req = new OrderRequest();
        req.item = item;
        req.itemId = MinecraftIds.itemToId(item);
        req.userId = MinecraftIds.userIdOf(mc.field_1724);
        req.qty = qty;
        req.price = price;
        return req;
    }

    private void onSell() {
        if (!requireConnected()) return;
        OrderRequest req = parseForm();
        if (req == null) return;

        class_310 mc = class_310.method_1551();

        // Remove physical items FIRST — never credit before removing.
        if (!InventoryBridge.remove(mc.field_1724, req.item, (int) req.qty)) {
            status = "You don't have " + req.qty + " of that";
            return;
        }

        // Deposit and list as one atomic event — two separate proposals could be
        // interleaved, leaving items deposited but never listed.
        Event.DepositAndList e = new Event.DepositAndList();
        e.userId = req.userId;
        e.itemId = req.itemId;
        e.quantity = req.qty;
        e.price = req.price;
        e.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(e),
                "Listed " + req.qty + " at " + req.price, "Sell sent...");
    }

    private void onBuy() {
        if (!requireConnected()) return;
        OrderRequest req = parseForm();
        if (req == null) return;

        Event.PlaceOrder order = new Event.PlaceOrder();
        order.userId = req.userId;
        order.itemId = req.itemId;
        order.price = req.price;
        order.volume = req.qty;
        order.isBid = true;
        order.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(order),
                "Bid placed for " + req.qty + " at " + req.price, "Buy sent...");
    }

    private void onWithdraw() {
        if (!requireConnected()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) { status = "No player"; return; }

        long qty;
        try {
            qty = Long.parseLong(amountField.method_1882().trim());
        } catch (NumberFormatException e) {
            status = "Amount must be a whole number";
            return;
        }
        if (qty <= 0) { status = "Amount must be positive"; return; }
        if (qty > MAX_QTY) { status = "Amount too large"; return; }

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) { status = "Unknown item"; return; }

        Event.Withdraw w = new Event.Withdraw();
        w.userId = MinecraftIds.userIdOf(mc.field_1724);
        w.itemId = MinecraftIds.itemToId(item);
        w.quantity = qty;
        w.timestamp = System.currentTimeMillis();

        MarketStateHolder.Submission s = MarketStateHolder.submit(w);
        if (s.pending) {
            status = "Withdraw sent...";
        } else if (s.accepted) {
            status = "Withdrew " + qty;
        } else {
            status = "Rejected: " + s.reason;
        }
    }

    private void onAddCredits() {
        if (!requireConnected()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        UUID uid = MinecraftIds.userIdOf(mc.field_1724);
        Event.InjectCredits ic = new Event.InjectCredits();
        ic.userId = uid;
        ic.targetUserId = uid;
        ic.amount = 1000;
        ic.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(ic), "Added 1000 credits", "Credits sent...");
    }

    private void onCancel() {
        if (!requireConnected()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        long orderId;
        try {
            orderId = Long.parseLong(cancelField.method_1882().trim().replace("#", ""));
        } catch (NumberFormatException e) {
            status = "Order ID must be a number";
            return;
        }

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) { status = "Unknown item"; return; }

        // The event needs the side; find the order to work out which book it's in.
        String itemId = MinecraftIds.itemToId(item);
        OrderBook book = MarketStateHolder.get().bookFor(itemId);
        Order o = book.find(orderId, true);
        boolean isBid = o != null;
        if (o == null) o = book.find(orderId, false);
        if (o == null) { status = "No such order in this item's book"; return; }

        Event.CancelOrder c = new Event.CancelOrder();
        c.userId = MinecraftIds.userIdOf(mc.field_1724);
        c.itemId = itemId;
        c.orderId = orderId;
        c.isBid = isBid;
        c.timestamp = System.currentTimeMillis();

        report(MarketStateHolder.submit(c), "Cancelled #" + orderId, "Cancel sent...");
    }

    private void report(MarketStateHolder.Submission s, String successMsg, String pendingMsg) {
        if (s.pending) {
            status = pendingMsg;
        } else if (s.accepted) {
            status = s.result.fills.isEmpty()
                    ? successMsg
                    : "Traded — " + s.result.fills.size() + " fill(s)";
        } else {
            status = "Rejected: " + s.reason;
        }
    }

    // ─────────── rendering ───────────

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        method_25420(matrices);

        method_27534(matrices, this.field_22793, this.field_22785, this.field_22789 / 2, 16, 0xFFFFFF);

        int listX = (int) (this.field_22789 * 0.08);

        label(matrices, "Amount", rowX, rowY - 11, 0xA0A0A0);
        label(matrices, "Item", rowX + ITEM_X_OFF, rowY - 11, 0xA0A0A0);
        label(matrices, "Price", rowX + PRICE_X_OFF, rowY - 11, 0xA0A0A0);
        label(matrices, "Cancel order", rowX, cancelY - 11, 0xA0A0A0);
        label(matrices, "Order book:", listX, rowY - 11, 0xFFFFFF);
        label(matrices, "Port", rowX + 310, connY - 11, 0xA0A0A0);

        renderConnectionStatus(matrices, listX, 30);
        renderBook(matrices, listX, rowY + 6);
        renderBalances(matrices, listX);
        renderDiscovery(matrices);

        if (!status.isEmpty()) {
            label(matrices, status, listX, this.field_22790 - 24, 0xFFDD66);
        }

        this.amountField.method_25394(matrices, mouseX, mouseY, delta);
        this.itemField.method_25394(matrices, mouseX, mouseY, delta);
        this.priceField.method_25394(matrices, mouseX, mouseY, delta);
        this.hostField.method_25394(matrices, mouseX, mouseY, delta);
        this.cancelField.method_25394(matrices, mouseX, mouseY, delta);
        this.hostPortField.method_25394(matrices, mouseX, mouseY, delta);

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    private void renderConnectionStatus(class_4587 matrices, int x, int y) {
        if (MarketStateHolder.mode() == MarketStateHolder.Mode.HOSTING) {
            label(matrices, "● hosting", x, y, 0xFFDD66);
        } else if (MarketStateHolder.isConnected()) {
            label(matrices, "● connected to host", x, y, 0x88FF88);
        } else if (MarketStateHolder.mode() == MarketStateHolder.Mode.CONNECTED) {
            label(matrices, "● connection lost", x, y, 0xFF8888);
        } else {
            label(matrices, "● market closed — not connected", x, y, 0xAAAAAA);
        }
    }

    private void renderBook(class_4587 matrices, int x, int startY) {
        class_310 mc = class_310.method_1551();
        UUID myUuid = mc.field_1724 != null ? MinecraftIds.userIdOf(mc.field_1724) : null;

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item == class_1802.field_8162) {
            label(matrices, "(enter an item to see its book)", x, startY, 0x808080);
            return;
        }

        String itemId = MinecraftIds.itemToId(item);
        MarketState market = MarketStateHolder.get();
        List<Order> asks = market.bookFor(itemId).restingAsks();
        List<Order> bids = market.bookFor(itemId).restingBids();

        if (asks.isEmpty() && bids.isEmpty()) {
            label(matrices, "(no orders)", x, startY, 0x808080);
            return;
        }

        int y = startY;
        int rowHeight = 13;

        int shown = 0;
        for (Order o : asks) {
            if (shown++ >= 6) break;
            boolean mine = myUuid != null && o.userID().equals(myUuid);
            label(matrices, (mine ? "* " : "  ") + "#" + o.orderId()
                            + " SELL " + o.volume() + " @ " + o.value(),
                    x, y, mine ? 0xFFCC66 : 0xFF8888);
            y += rowHeight;
        }

        y += 4;
        shown = 0;
        for (Order o : bids) {
            if (shown++ >= 6) break;
            boolean mine = myUuid != null && o.userID().equals(myUuid);
            label(matrices, (mine ? "* " : "  ") + "#" + o.orderId()
                            + " BUY  " + o.volume() + " @ " + o.value(),
                    x, y, mine ? 0xFFCC66 : 0x88FF88);
            y += rowHeight;
        }
    }

    private void renderBalances(class_4587 matrices, int x) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        UUID userId = MinecraftIds.userIdOf(mc.field_1724);
        MarketState market = MarketStateHolder.get();

        int y = this.field_22790 - 50;
        label(matrices, "Credits: " + market.wallets().getBalance(userId), x, y, 0xFFFF88);

        class_1792 item = MinecraftIds.itemFromName(itemField.method_1882().trim());
        if (item != class_1802.field_8162) {
            long held = market.itemBalances().getBalance(userId, MinecraftIds.itemToId(item));
            label(matrices, "Market credit: " + held + " " + item.method_7848().getString(),
                    x, y + 13, 0xFFFF88);
        }
    }

    private void label(class_4587 m, String s, int x, int y, int colour) {
        method_27535(m, this.field_22793, new class_2585(s), x, y, colour);
    }

    private static class OrderRequest {
        class_1792 item;
        String itemId;
        UUID userId;
        long qty;
        long price;
    }

    /** Reads the port field, falling back to 25555 if it's not a valid number. */
    private int hostPortFromField() {
        try {
            int p = Integer.parseInt(hostPortField.method_1882().trim());
            return (p >= 1024 && p <= 65535) ? p : 25555;
        } catch (NumberFormatException e) {
            return 25555;
        }
    }

    @Override
    public void method_25432() {
        resetArmed = false;
        hostArmed = false;
        savedItemText = itemField.method_1882();
        savedItemText = itemField.method_1882();
        savedHostText = hostField.method_1882();
        savedPortText = hostPortField.method_1882();
        super.method_25432();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_M
                && !amountField.method_25370()
                && !itemField.method_25370()
                && !priceField.method_25370()
                && !hostField.method_25370()
                && !hostPortField.method_25370()
                && !cancelField.method_25370()) {
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

}