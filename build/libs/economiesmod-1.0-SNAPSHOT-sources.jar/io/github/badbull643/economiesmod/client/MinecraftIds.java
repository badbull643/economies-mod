package io.github.badbull643.economiesmod.client;

import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class MinecraftIds {
    public static String itemToId(class_1792 item) {
        return class_2378.field_11142.method_10221(item).toString();   // "minecraft:iron_ingot"
    }

    public static class_1792 idToItem(String id) {
        return class_2378.field_11142.method_10223(new class_2960(id));
    }

    public static class_1792 itemFromName(String name) {
        return class_2378.field_11142.method_10223(new class_2960(name));
    }

    public static UUID userIdOf(class_1657 player) {
        return player.method_5667();
    }
}
