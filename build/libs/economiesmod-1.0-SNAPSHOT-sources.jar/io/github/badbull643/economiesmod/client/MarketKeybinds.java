package io.github.badbull643.economiesmod.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class MarketKeybinds {

    public static class_304 openMarketKey;

    public static void register() {
        openMarketKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.economiesmod.openmarket",      // translation key
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_M,                    // default bound to M
                "key.category.economiesmod"         // category translation key
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMarketKey.method_1436()) {    // 1.16.5: wasPressed(), not consumeClick()

                //opens a new market screen
                if (client.field_1755 instanceof MarketScreen) {
                    // Market is open → close it (null = return to game)
                    client.method_1507(null);
                } else if (client.field_1755 == null) {
                    // No screen open → open the market
                    client.method_1507(new MarketScreen());
                }
            }
        });
    }
}