package io.github.badbull643.economiesmod.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class MarketKeybinds {

    public static class_304 openMarketKey;

    public static void register() {
        openMarketKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.economiesmod.openmarket",      // translation key
                class_3675.class_307.field_1668,
                // Unbound by default, so this mod claims no key until asked. M is a
                // reasonable key for a market and a reasonable key for a dozen other
                // mods, and a fresh install silently taking it is how keys get fought
                // over. The player binds it in Options → Controls → EconomiesMod, which
                // is where somebody looking for a keybind already looks.
                //
                // There are two other ways in that need no key at all — the inventory
                // button and /trade — so an unbound default costs nobody access.
                GLFW.GLFW_KEY_UNKNOWN,
                "key.category.economiesmod"         // category translation key
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMarketKey.method_1436()) {    // 1.16.5: wasPressed(), not consumeClick()

                //opens a new market screen
                if (client.field_1755 instanceof MarketScreen) {
                    // Market is open → close it (null = return to game)
                    client.method_1507(null);
                } else if (client.field_1755 == null) {
                    // No screen open → open the market
                    client.method_1507(new MarketScreen());
                }
            }
        });
    }
}