package io.github.badbull643.economiesmod.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.class_5218;
import java.nio.file.Path;

public class EconomiesmodClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        MarketKeybinds.register();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            Path worldDir = server.method_27050(class_5218.field_24188);
            MarketStateHolder.load(worldDir);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            MarketStateHolder.save();
        });
    }
}
