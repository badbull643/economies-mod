package io.github.badbull643.economiesmod.client;

import io.github.badbull643.economiesmod.core.Event;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_5218;
import java.nio.file.Path;

public class EconomiesmodClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        MarketKeybinds.register();


        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            class_310 mc = class_310.method_1551();
            String name = mc.method_1548().method_1676();
            Path configDir = FabricLoader.getInstance().getConfigDir();

            MarketStateHolder.loadKeys(configDir.resolve("economiesmod-identity-" + name + ".key"));
            MarketStateHolder.loadPeers(configDir.resolve("economiesmod-peers-" + name + ".json"));

            MarketStateHolder.ensureShareFolders();

            Path worldDir = server.method_27050(class_5218.field_24188);
            MarketStateHolder.loadLocal(worldDir);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            System.out.println("[economiesmod] world stopping — shutting down");
            MarketStateHolder.shutdown();
        });

        MarketStateHolder.setOnApplied(se -> {
            if (!(se.event instanceof Event.Withdraw)) return;

            Event.Withdraw w = (Event.Withdraw) se.event;
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null) return;

            // Only grant for our own withdrawals — everyone else's are just ledger changes.
            if (!w.userId.equals(MinecraftIds.userIdOf(mc.field_1724))) return;

            class_1792 item = MinecraftIds.idToItem(w.itemId);
            if (item == class_1802.field_8162) return;

            // This may fire on the network reader thread — inventory work must be on
            // the game thread.
            mc.execute(() -> InventoryBridge.give(mc.field_1724, item, (int) w.quantity));
        });

    }
}
