package io.github.badbull643.economiesmod.client;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Bridges the engine's ledger to real Minecraft inventories.
 *
 * IMPORTANT: all operations run against the SERVER-side player. Editing the
 * client-side player only changes what you see locally — the server overwrites
 * it on the next sync, which would let the same items be sold repeatedly.
 *
 * Assumes an integrated (singleplayer) server. Real multiplayer would need
 * client-to-server packets instead.
 */
public class InventoryBridge {

    /** Resolves the authoritative server-side player, or null if unavailable. */
    private static class_3222 serverPlayer(class_1657 player) {
        MinecraftServer server = class_310.method_1551().method_1576();
        if (server == null) return null;
        return server.method_3760().method_14602(player.method_5667());
    }

    /** Counts how many of `item` the player has, ignoring NBT-bearing stacks. */
    public static int count(class_1657 player, class_1792 item) {
        class_3222 sp = serverPlayer(player);
        if (sp == null) return 0;

        int total = 0;
        class_1661 inv = sp.field_7514;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7909() == item && !stack.method_7985()) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    /** Removes exactly `qty` of `item`. Returns false and changes nothing if insufficient. */
    public static boolean remove(class_1657 player, class_1792 item, int qty) {
        class_3222 sp = serverPlayer(player);
        if (sp == null) return false;

        if (count(player, item) < qty) return false;

        int remaining = qty;
        class_1661 inv = sp.field_7514;
        for (int i = 0; i < inv.method_5439() && remaining > 0; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7909() == item && !stack.method_7985()) {
                int take = Math.min(remaining, stack.method_7947());
                stack.method_7934(take);
                remaining -= take;
            }
        }

        inv.method_5431();
        sp.field_7498.method_7623();

        return remaining == 0;
    }

    /** Gives items to the player, dropping any that don't fit. */
    public static void give(class_1657 player, class_1792 item, int qty) {
        class_3222 sp = serverPlayer(player);
        if (sp == null) return;

        int maxStack = item.method_7882();
        while (qty > 0) {
            int stackSize = Math.min(qty, maxStack);
            sp.method_7270(new class_1799(item, stackSize));
            qty -= stackSize;
        }

        sp.field_7514.method_5431();
        sp.field_7498.method_7623();
    }
}