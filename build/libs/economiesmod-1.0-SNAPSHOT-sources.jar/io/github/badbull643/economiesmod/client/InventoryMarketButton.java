package io.github.badbull643.economiesmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.badbull643.economiesmod.mixin.HandledScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_4264;
import net.minecraft.class_4587;
import net.minecraft.class_490;
import net.minecraft.class_5250;
import net.minecraft.class_918;

/**
 * A way into the market from the inventory, next to the recipe book.
 *
 * The keybind is not discoverable. Nothing in the game says the market is on M, so a
 * player who installs the mod and never reads its page never finds it — and the
 * inventory is both where items live and where someone wondering what to do with their
 * items already is.
 *
 * Added, never substituted: M still works and is still the fast way in. This is the
 * path for people who don't know M exists yet.
 */
public final class InventoryMarketButton {

    /**
     * Beside vanilla's recipe-book button, which sits at x+104 and is 20 wide.
     *
     * The band between the crafting grid and the inventory rows is empty in the vanilla
     * texture, and the recipe book expands leftward, so nothing here gets covered when
     * it opens.
     */
    private static final int OFFSET_X = 126;

    /** Exactly the recipe button's footprint, so the pair reads as one row of controls. */
    private static final int WIDTH = 20;
    private static final int HEIGHT = 18;

    /** The shared button texture is 20 tall, whatever height we draw it at. */
    private static final int TEXTURE_HEIGHT = 20;

    private static final class_2561 LABEL = new class_2585("Market");

    private InventoryMarketButton() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledW, scaledH) -> {
            if (!(screen instanceof class_490)) return;
            Screens.getButtons(screen).add(new OpenMarket((class_490) screen));
        });
    }

    /**
     * Extends PressableWidget rather than ButtonWidget purely for draw order.
     *
     * ButtonWidget.renderButton draws the background and then, if hovered, the tooltip —
     * which leaves nowhere to put the icon: after that call it lands on top of the
     * tooltip, before it the background covers it. PressableWidget draws only the
     * background, so the three can be sequenced properly.
     */
    private static final class OpenMarket extends class_4264 {

        private final class_490 owner;

        OpenMarket(class_490 owner) {
            // Blank, because PressableWidget draws the message centred in the button and
            // "Market" is far wider than 20px — it spilled out over the slots on both
            // sides. The name belongs to the tooltip, and to the narrator below.
            super(0, 0, WIDTH, HEIGHT, new class_2585(""));
            this.owner = owner;
        }

        @Override
        protected class_5250 method_25360() {
            return new class_2588("gui.narrate.button", LABEL);
        }

        @Override
        public void method_25306() {
            class_310.method_1551().method_1507(new MarketScreen());
        }

        @Override
        public void method_25359(class_4587 m, int mouseX, int mouseY, float delta) {
            follow();
            drawFrame(m);
            drawEmerald(m);
            if (method_25367()) owner.method_25424(m, LABEL, mouseX, mouseY);
        }

        /**
         * The vanilla button frame, drawn at a height it was never cut for.
         *
         * ClickableWidget passes its own height through as the texture's <em>source</em>
         * height, so at 18 it samples the top 18 rows of a 20-row button and the bottom
         * bevel is simply never drawn — which is what read as permanently pressed in.
         *
         * Drawn here as four pieces instead: each half takes its 9 rows from the matching
         * end of the source, so both bevels survive and the two middle rows are the only
         * thing dropped. That is the same trick vanilla itself uses for stretched widgets,
         * and it lets this match the recipe button's 20x18 exactly rather than standing
         * two pixels taller beside it.
         */
        private void drawFrame(class_4587 m) {
            class_310.method_1551().method_1531().method_22813(field_22757);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableDepthTest();

            int v = 46 + method_25356(method_25367()) * TEXTURE_HEIGHT;
            int halfW = WIDTH / 2;
            int halfH = HEIGHT / 2;
            int lowerV = v + TEXTURE_HEIGHT - halfH;
            int rightU = 200 - halfW;

            method_25302(m, this.field_22760, this.field_22761, 0, v, halfW, halfH);
            method_25302(m, this.field_22760 + halfW, this.field_22761, rightU, v, halfW, halfH);
            method_25302(m, this.field_22760, this.field_22761 + halfH, 0, lowerV, halfW, halfH);
            method_25302(m, this.field_22760 + halfW, this.field_22761 + halfH, rightU, lowerV, halfW, halfH);
        }

        /**
         * Re-anchors to the panel every frame.
         *
         * init() is not enough: opening the recipe book shifts the whole GUI and only
         * vanilla's own button is moved to match. Doing it here rather than from a
         * render callback also means it survives init() running more than once, which
         * it does on every window resize.
         */
        private void follow() {
            this.field_22760 = ((HandledScreenAccessor) owner).getPanelX() + OFFSET_X;
            // The same y vanilla gives the recipe button, since this is now the same size.
            this.field_22761 = owner.field_22790 / 2 - 22;
        }

        /** The emerald is the mod's mark for money, and matches the credit line. */
        private void drawEmerald(class_4587 m) {
            class_918 items = class_310.method_1551().method_1480();

            // Depth testing is already on — ClickableWidget enables it before drawing
            // the button texture — but it is asserted rather than assumed, because item
            // models need it and a stray disabled one is silent. Restored afterwards to
            // the state HandledScreen sets around its own buttons.
            items.field_4730 = 100.0F;
            RenderSystem.enableDepthTest();
            items.method_27953(new class_1799(class_1802.field_8687), this.field_22760 + 2, this.field_22761 + 1);
            items.field_4730 = 0.0F;
            RenderSystem.disableDepthTest();
        }
    }
}
