package io.github.badbull643.economiesmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.badbull643.economiesmod.mixin.HandledScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_4264;
import net.minecraft.class_4587;
import net.minecraft.class_490;
import net.minecraft.class_918;

/**
 * A way into the market from the inventory, next to the recipe book.
 *
 * The keybind is not discoverable. Nothing in the game says the market is on M, so a
 * player who installs the mod and never reads its page never finds it — and the
 * inventory is both where items live and where someone wondering what to do with their
 * items already is.
 *
 * Added, never substituted: M still works and is still the fast way in. This is the
 * path for people who don't know M exists yet.
 */
public final class InventoryMarketButton {

    /**
     * Beside vanilla's recipe-book button, which sits at x+104 and is 20 wide.
     *
     * The band between the crafting grid and the inventory rows is empty in the vanilla
     * texture, and the recipe book expands leftward, so nothing here gets covered when
     * it opens.
     */
    private static final int OFFSET_X = 126;
    private static final int WIDTH = 20;
    private static final int HEIGHT = 18;

    private static final class_2561 LABEL = new class_2585("Market");

    private InventoryMarketButton() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledW, scaledH) -> {
            if (!(screen instanceof class_490)) return;
            Screens.getButtons(screen).add(new OpenMarket((class_490) screen));
        });
    }

    /**
     * Extends PressableWidget rather than ButtonWidget purely for draw order.
     *
     * ButtonWidget.renderButton draws the background and then, if hovered, the tooltip —
     * which leaves nowhere to put the icon: after that call it lands on top of the
     * tooltip, before it the background covers it. PressableWidget draws only the
     * background, so the three can be sequenced properly.
     */
    private static final class OpenMarket extends class_4264 {

        private final class_490 owner;

        OpenMarket(class_490 owner) {
            super(0, 0, WIDTH, HEIGHT, LABEL);
            this.owner = owner;
        }

        @Override
        public void method_25306() {
            class_310.method_1551().method_1507(new MarketScreen());
        }

        @Override
        public void method_25359(class_4587 m, int mouseX, int mouseY, float delta) {
            follow();
            super.method_25359(m, mouseX, mouseY, delta);
            drawEmerald(m);
            if (method_25367()) owner.method_25424(m, LABEL, mouseX, mouseY);
        }

        /**
         * Re-anchors to the panel every frame.
         *
         * init() is not enough: opening the recipe book shifts the whole GUI and only
         * vanilla's own button is moved to match. Doing it here rather than from a
         * render callback also means it survives init() running more than once, which
         * it does on every window resize.
         */
        private void follow() {
            this.field_22760 = ((HandledScreenAccessor) owner).getPanelX() + OFFSET_X;
            this.field_22761 = owner.field_22790 / 2 - 22;
        }

        /** The emerald is the mod's mark for money, and matches the credit line. */
        private void drawEmerald(class_4587 m) {
            class_918 items = class_310.method_1551().method_1480();

            // HandledScreen turns depth testing off before rendering its buttons, and
            // item models need it on. Turn it back off afterwards rather than leaving it
            // — a stray enabled depth test is what made panels punch through each other
            // the last time icons were drawn outside a place that expected them.
            items.field_4730 = 100.0F;
            RenderSystem.enableDepthTest();
            items.method_27953(new class_1799(class_1802.field_8687), this.field_22760 + 2, this.field_22761 + 1);
            items.field_4730 = 0.0F;
            RenderSystem.disableDepthTest();
        }
    }
}
